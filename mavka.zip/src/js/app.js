import * as flsFunctions from "./modules/functions.js";

import "./burger.js";
import "./swiper.js";
import "./modal.js";

flsFunctions.isWebp();
