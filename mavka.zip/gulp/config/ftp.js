export let configFTP = {
  host: "", // адрес FTP сервера
  user: "", // імя користувача
  password: "", // пароль
  parallel: 5, // кіль-сть одночасний потоків
};
